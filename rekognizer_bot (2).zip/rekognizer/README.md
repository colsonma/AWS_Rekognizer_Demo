# Rekognizer bot

## Setup instructions

1. Visit https://api.slack.com/apps and click __Create New App__. Name
   your app and click __Create App__.

1. Navigate to __Bot Users__. Click __Add a Bot User__. Confirm your
   bot's name and click __Add Bot User__.

1. Navigate to __Event Subscriptions__.

   * Next to __Enable Events__, toggle the switch to __On__.

   * Scroll down to __Bot Events__. Click __Add Bot User Event__ and
     choose `message.channels`.

   * Click __Save Changes__.

1. Navigate to __Basic Information__ and note your app ID, app secret,
   and verification token.

1. Clone this repository onto a Linux host with `pip` and the AWS CLI
   installed.

1. Run `bin/build` to build and upload the Lambda artifacts.

1. Run `bin/launch` to deploy the CloudFormation template. To complete
   installation:

   * Navigate to __OAuth &amp; Permissions__. Paste the OAuth callback
     URL in the __Redirect URL(s)__ box and click __Save Changes__.

   * Navigate to __Event Subscriptions__. Paste the event target URL
     in the __Request URL__ box and click __Verify__.

   * Next to __Enable Events__, toggle the switch to __On__.

   * Click __Save Changes__.

   * Paste the OAuth link into your web browser and complete the OAuth flow.
