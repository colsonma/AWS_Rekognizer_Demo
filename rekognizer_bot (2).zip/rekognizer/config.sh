# Configuration information for your environment

DIST_BUCKET="rekognizer-dist-fdgjmtyrnejrlzrh"
STACK_NAME="rekognizer-fdgjmtyrnejrlzrh"
TEMPLATE=template.yaml
