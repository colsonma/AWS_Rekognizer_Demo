import base64
import boto3
import json
import logging
import os

kms = boto3.client('kms')

def decrypt(ciphertext):
    return kms.decrypt(
        CiphertextBlob=base64.b64decode(ciphertext))['Plaintext']

SLACK_VERIFICATION_TOKEN = decrypt(os.environ['SLACK_VERIFICATION_TOKEN'])
ASYNC_FUNCTION_NAME      = os.environ['ASYNC_FUNCTION_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

lambda_ = boto3.client('lambda')

def lambda_handler(event, context):
    logger.info(json.dumps(event, indent=4))

    if event['token'] != SLACK_VERIFICATION_TOKEN:
        return { 'error': 'Bad request' }

    # Handle Slack URL verification: https://api.slack.com/events/url_verification
    if event['type'] == 'url_verification':
        return { 'challenge': event['challenge'] }

    if event['type'] == 'event_callback' and event['event'].get('subtype') == 'file_share':
        lambda_.invoke(
            FunctionName=ASYNC_FUNCTION_NAME,
            InvocationType='Event',
            Payload=json.dumps(event))
