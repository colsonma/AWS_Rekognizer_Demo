import base64
import boto3
import json
import logging
import os
import slackclient

logger = logging.getLogger()
logger.setLevel(logging.INFO)

kms = boto3.client('kms')

def encrypt(plaintext):
    return base64.b64encode(kms.encrypt(
        KeyId=KMS_KEY_ID, Plaintext=plaintext)['CiphertextBlob'])

def decrypt(ciphertext):
    return kms.decrypt(
        CiphertextBlob=base64.b64decode(ciphertext))['Plaintext']

DYNAMODB_TABLE      = os.environ['DYNAMODB_TABLE']
KMS_KEY_ID          = os.environ['KMS_KEY_ID']
SLACK_CLIENT_ID     = os.environ['SLACK_CLIENT_ID']
SLACK_CLIENT_SECRET = decrypt(os.environ['SLACK_CLIENT_SECRET'])

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(DYNAMODB_TABLE)

def lambda_handler(event, context):
    logger.info(json.dumps(event, indent=4))

    slack = slackclient.SlackClient('')
    resp = slack.api_call('oauth.access',
                          client_id=SLACK_CLIENT_ID,
                          client_secret=SLACK_CLIENT_SECRET,
                          code=event['code'])

    assert resp['ok']

    table.put_item(Item={
        'team_id'          : resp['team_id'],
        'team_name'        : resp['team_name'],
        'user_id'          : resp['user_id'],
        'access_token'     : encrypt(resp['access_token']),
        'bot_user_id'      : resp['bot']['bot_user_id'],
        'bot_access_token' : encrypt(resp['bot']['bot_access_token']),
        'scope'            : resp['scope']
    })

    return {
        'ok': True,
        'team_id': resp['team_id'],
        'team_name': resp['team_name']
    }
