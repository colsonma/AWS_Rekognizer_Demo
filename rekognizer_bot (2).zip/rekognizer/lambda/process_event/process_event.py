import base64
import boto3
import collections
import emoji
import json
import logging
import os
import requests
import shutil
import slackclient

from PIL import Image

kms = boto3.client('kms')

def decrypt(ciphertext):
    return kms.decrypt(
        CiphertextBlob=base64.b64decode(ciphertext))['Plaintext']

DYNAMODB_TABLE      = os.environ['DYNAMODB_TABLE']
S3_BUCKET           = os.environ['S3_BUCKET']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(DYNAMODB_TABLE)

s3 = boto3.resource('s3')
bucket = s3.Bucket(S3_BUCKET)

rekognition = boto3.client('rekognition')

EMOJI_MAP = collections.OrderedDict([
    ('Gender'     , { 'Male': 'man', 'Female': 'woman' }),
    ('Eyeglasses' , { True: 'eyeglasses' }),
    ('Sunglasses' , { True: 'sunglasses' }),
    ('Smile'      , { False: 'neutral_face', True: 'grinning_face' }),
    ('Emotions'   , {
        'HAPPY'     : 'happy_person_raising_one_hand',
        'SAD'       : 'person_frowning',
        'ANGRY'     : 'pouting_face',
        'CONFUSED'  : 'confused_face',
        'CALM'      : 'face_massage',
        'DISGUSTED' : 'confounded_face',
        'SURPRISED' : 'astonished_face'
    }),
    ('MouthOpen', { True: 'face_with_open_mouth' }),
    # ('EyesOpen' , { False: 'expressionless_face' }),
    ('Beard'    , { True: 'father_christmas'})
    # ('Mustache' : { False: 'older_man' }),
])

def face_emoji(face_details):
    out = []

    for detail, emojis in EMOJI_MAP.iteritems():
        details = face_details[detail]
        if type(details) is list:
            key = details[0]['Type']
        else:
            key = details['Value']

        emoji_name = emojis.get(key)
        if emoji_name is not None:
            out.append(emoji.emojize(':' + emoji_name + ':'))

    return ''.join(out)

SOURCE_PATH = '/tmp/source'

def lambda_handler(event, context):
    logger.info(json.dumps(event, indent=4))

    if event['event'].get('subtype') == 'file_share':
        fileinfo = event['event']['file']
    else:
        logger.info('Not a file share event')
        return

    if fileinfo.get('mimetype') not in ('image/jpeg', 'image/png'):
        logger.info('Unsupported mimetype {}'.format(fileinfo.get('mimetype')))
        return

    # Get team info
    team = table.get_item(Key={'team_id': event['team_id']})['Item']
    team['access_token']     = decrypt(team['access_token'])
    team['bot_access_token'] = decrypt(team['bot_access_token'])

    # Download file
    headers = {'Authorization': 'Bearer ' + team['bot_access_token']}
    image_resp = requests.get(fileinfo['url_private'], headers=headers, stream=True)
    image_id = base64.b32encode(os.urandom(20))

    with open(SOURCE_PATH, 'wb') as f:
        shutil.copyfileobj(image_resp.raw, f)

    bucket.upload_file(SOURCE_PATH, image_id)

    # Detect labels
    rekog_resp = rekognition.detect_labels(
        Image={'S3Object': { 'Bucket': S3_BUCKET, 'Name': image_id }})

    if len(rekog_resp['Labels']) == 0:
        logger.info('No labels detected')
        return

    # Compose a message
    msg = ', '.join(["{Name} ({Confidence:.0f}%)".format(**l)
                     for l in rekog_resp['Labels']])

    # Detect faces
    faces_resp = rekognition.detect_faces(
        Image={'S3Object': { 'Bucket': S3_BUCKET, 'Name': image_id }},
        Attributes=['ALL']
    )

    im = Image.open(SOURCE_PATH)

    attachments = []

    faces = faces_resp['FaceDetails']
    for i, face in enumerate(faces):
        # Convert the floating point bounding box to the 4-tuple PIL expects
        box_f = face['BoundingBox']
        h = int(round(box_f['Height'] * im.height))
        w = int(round(box_f['Width'] * im.width))
        t = int(round(box_f['Top'] * im.height))
        l = int(round(box_f['Left'] * im.width))
        box = (l, t, l+w, t+h)

        region = im.crop(box)
        face_path = '/tmp/face_{}.jpg'.format(i)
        region.save(face_path)

        face_key = 'faces/{}.jpg'.format(
            base64.b32encode(os.urandom(30)).lower())
        bucket.upload_file(face_path, face_key)

        attachments.append({
            'fallback': 'Detected face {}'.format(i),
            'text': face_emoji(face),
            'thumb_url': 'https://s3.amazonaws.com/{}/{}'.format(
                S3_BUCKET, face_key)
        })

    logger.info(json.dumps(attachments, indent=4))

    slack = slackclient.SlackClient(team['bot_access_token'])
    slack_resp = slack.api_call('chat.postMessage',
                                channel=event['event']['channel'],
                                text=msg,
                                attachments=attachments)

    logger.info(json.dumps(slack_resp, indent=4))
